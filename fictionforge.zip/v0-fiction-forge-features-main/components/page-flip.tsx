"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { motion, AnimatePresence } from "framer-motion"

interface PageFlipProps {
  children: React.ReactNode
}

export function PageFlip({ children }: PageFlipProps) {
  const [isFlipping, setIsFlipping] = useState(false)
  const [content, setContent] = useState(children)
  const [newContent, setNewContent] = useState<React.ReactNode | null>(null)
  const prevChildrenRef = useRef(children)

  useEffect(() => {
    if (children !== prevChildrenRef.current) {
      setIsFlipping(true)
      setNewContent(children)
      prevChildrenRef.current = children
    }
  }, [children])

  const handleAnimationComplete = () => {
    if (isFlipping) {
      setContent(newContent)
      setIsFlipping(false)
    }
  }

  return (
    <div className="relative overflow-hidden">
      <AnimatePresence mode="wait" onExitComplete={handleAnimationComplete}>
        <motion.div
          key={isFlipping ? "flipping" : "static"}
          initial={isFlipping ? { rotateY: 0, opacity: 1 } : { rotateY: 0, opacity: 1 }}
          animate={isFlipping ? { rotateY: 90, opacity: 0 } : { rotateY: 0, opacity: 1 }}
          exit={isFlipping ? { rotateY: 90, opacity: 0 } : { rotateY: 0, opacity: 1 }}
          transition={{ duration: 0.3, ease: "easeInOut" }}
          style={{ transformStyle: "preserve-3d", perspective: "1000px" }}
        >
          {isFlipping ? content : content}
        </motion.div>
      </AnimatePresence>
    </div>
  )
}
