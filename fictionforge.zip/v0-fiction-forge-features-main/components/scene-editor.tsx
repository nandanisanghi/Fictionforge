"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { PlusCircle, Trash2, ImageIcon, Save } from "lucide-react"
import { useStoryStore } from "@/lib/store"
import type { StoryNode } from "@/lib/types"

interface SceneEditorProps {
  nodeId: string
}

export default function SceneEditor({ nodeId }: SceneEditorProps) {
  const { nodes, updateNode } = useStoryStore()
  const [node, setNode] = useState<StoryNode | null>(null)
  const [newChoice, setNewChoice] = useState("")

  useEffect(() => {
    const foundNode = nodes.find((n) => n.id === nodeId)
    if (foundNode) {
      setNode(foundNode)
    }
  }, [nodeId, nodes])

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (node) {
      setNode({
        ...node,
        title: e.target.value,
      })
    }
  }

  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    if (node) {
      setNode({
        ...node,
        content: e.target.value,
      })
    }
  }

  const handleImageUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (node) {
      setNode({
        ...node,
        imageUrl: e.target.value,
      })
    }
  }

  const handleAddChoice = () => {
    if (node && newChoice.trim()) {
      const updatedNode = {
        ...node,
        choices: [...(node.choices || []), { id: `choice-${Date.now()}`, text: newChoice, targetId: null }],
      }
      setNode(updatedNode)
      setNewChoice("")
    }
  }

  const handleRemoveChoice = (choiceId: string) => {
    if (node) {
      setNode({
        ...node,
        choices: (node.choices || []).filter((choice) => choice.id !== choiceId),
      })
    }
  }

  const handleSave = () => {
    if (node) {
      updateNode(node)
    }
  }

  if (!node) {
    return (
      <div className="text-center py-16 bg-amber-100 rounded-lg border border-amber-200">
        <p className="text-amber-700">Loading scene...</p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="md:col-span-2">
        <Card className="border-amber-200 bg-amber-100">
          <CardHeader>
            <CardTitle className="text-amber-800">Scene Editor</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="title" className="text-amber-800">
                Scene Title
              </Label>
              <Input
                id="title"
                value={node.title}
                onChange={handleTitleChange}
                className="border-amber-300 focus:border-amber-500 focus:ring-amber-500"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="content" className="text-amber-800">
                Scene Content
              </Label>
              <Textarea
                id="content"
                value={node.content}
                onChange={handleContentChange}
                rows={10}
                className="border-amber-300 focus:border-amber-500 focus:ring-amber-500 font-serif"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="imageUrl" className="text-amber-800 flex items-center">
                <ImageIcon className="mr-2 h-4 w-4" />
                Scene Image URL (Optional)
              </Label>
              <Input
                id="imageUrl"
                value={node.imageUrl || ""}
                onChange={handleImageUrlChange}
                placeholder="https://example.com/image.jpg"
                className="border-amber-300 focus:border-amber-500 focus:ring-amber-500"
              />
              {node.imageUrl && (
                <div className="mt-2 h-40 overflow-hidden rounded-md border border-amber-300">
                  <img
                    src={node.imageUrl || "/placeholder.svg?height=200&width=300"}
                    alt="Scene"
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=200&width=300"
                    }}
                  />
                </div>
              )}
            </div>

            <div className="pt-4 flex justify-end">
              <Button onClick={handleSave} className="bg-amber-800 hover:bg-amber-900 text-amber-50">
                <Save className="mr-2 h-4 w-4" />
                Save Scene
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <div>
        <Card className="border-amber-200 bg-amber-100">
          <CardHeader>
            <CardTitle className="text-amber-800">Choices</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {node.choices && node.choices.length > 0 ? (
                <div className="space-y-2">
                  {node.choices.map((choice) => (
                    <div
                      key={choice.id}
                      className="flex items-center justify-between p-2 bg-amber-200 rounded border border-amber-300"
                    >
                      <span className="text-amber-800 truncate mr-2">{choice.text}</span>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-6 w-6 text-amber-800 hover:bg-amber-300 hover:text-amber-900"
                        onClick={() => handleRemoveChoice(choice.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-amber-700 text-sm">No choices added yet. Add choices to create branching paths.</p>
              )}

              <div className="pt-2 space-y-2">
                <Label htmlFor="newChoice" className="text-amber-800">
                  Add New Choice
                </Label>
                <div className="flex space-x-2">
                  <Input
                    id="newChoice"
                    value={newChoice}
                    onChange={(e) => setNewChoice(e.target.value)}
                    placeholder="Enter choice text..."
                    className="border-amber-300 focus:border-amber-500 focus:ring-amber-500"
                  />
                  <Button onClick={handleAddChoice} className="bg-amber-800 hover:bg-amber-900 text-amber-50">
                    <PlusCircle className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
