"use client"

import { useEffect, useState } from "react"

interface TypewriterEffectProps {
  text: string
  className?: string
  speed?: number
}

export default function TypewriterEffect({ text, className = "", speed = 50 }: TypewriterEffectProps) {
  const [displayText, setDisplayText] = useState("")
  const [currentIndex, setCurrentIndex] = useState(0)

  useEffect(() => {
    if (currentIndex < text.length) {
      const timeout = setTimeout(() => {
        setDisplayText((prev) => prev + text[currentIndex])
        setCurrentIndex((prev) => prev + 1)
      }, speed)

      return () => clearTimeout(timeout)
    }
  }, [currentIndex, text, speed])

  return (
    <div className={className}>
      {displayText}
      {currentIndex < text.length && <span className="animate-pulse">|</span>}
    </div>
  )
}
