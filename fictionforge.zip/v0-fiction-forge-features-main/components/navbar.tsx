"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { BookOpen, PenTool, User, Menu, X } from "lucide-react"
import { useState } from "react"

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <nav className="bg-amber-800 text-amber-50 py-4 px-6 shadow-md">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <Link href="/" className="flex items-center space-x-2">
          <BookOpen className="h-6 w-6" />
          <span className="text-xl font-bold">FictionForge</span>
        </Link>

        {/* Mobile menu button */}
        <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>

        {/* Desktop navigation */}
        <div className="hidden md:flex items-center space-x-6">
          <Link href="/stories" className="hover:text-amber-200 transition-colors">
            My Stories
          </Link>
          <Link href="/explore" className="hover:text-amber-200 transition-colors">
            Explore
          </Link>
          <Link href="/help" className="hover:text-amber-200 transition-colors">
            Help
          </Link>
          <Button asChild variant="outline" className="border-amber-50 text-amber-50 hover:bg-amber-700">
            <Link href="/stories/new">
              <PenTool className="mr-2 h-4 w-4" />
              New Story
            </Link>
          </Button>
          <Button size="icon" variant="ghost" className="rounded-full hover:bg-amber-700">
            <User className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden mt-4 space-y-4 px-2 pb-4">
          <Link
            href="/stories"
            className="block py-2 px-4 hover:bg-amber-700 rounded-md transition-colors"
            onClick={() => setIsMenuOpen(false)}
          >
            My Stories
          </Link>
          <Link
            href="/explore"
            className="block py-2 px-4 hover:bg-amber-700 rounded-md transition-colors"
            onClick={() => setIsMenuOpen(false)}
          >
            Explore
          </Link>
          <Link
            href="/help"
            className="block py-2 px-4 hover:bg-amber-700 rounded-md transition-colors"
            onClick={() => setIsMenuOpen(false)}
          >
            Help
          </Link>
          <Link
            href="/stories/new"
            className="block py-2 px-4 bg-amber-700 hover:bg-amber-600 rounded-md transition-colors"
            onClick={() => setIsMenuOpen(false)}
          >
            <div className="flex items-center">
              <PenTool className="mr-2 h-4 w-4" />
              New Story
            </div>
          </Link>
        </div>
      )}
    </nav>
  )
}
