"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { PlusCircle, Trash2, ZoomIn, ZoomOut, Maximize, Minimize } from "lucide-react"
import { useStoryStore } from "@/lib/store"

interface StoryCanvasProps {
  onNodeSelect: (nodeId: string) => void
}

export default function StoryCanvas({ onNodeSelect }: StoryCanvasProps) {
  const { nodes, connections, addNode, removeNode, updateNodePosition, addConnection } = useStoryStore()

  const [zoom, setZoom] = useState(1)
  const [isDragging, setIsDragging] = useState(false)
  const [draggedNodeId, setDraggedNodeId] = useState<string | null>(null)
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 })
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [canvasOffset, setCanvasOffset] = useState({ x: 0, y: 0 })
  const [isConnecting, setIsConnecting] = useState(false)
  const [connectionStart, setConnectionStart] = useState<string | null>(null)

  const canvasRef = useRef<HTMLDivElement>(null)

  const handleAddNode = () => {
    const centerX = canvasRef.current ? canvasRef.current.clientWidth / 2 / zoom - canvasOffset.x : 100
    const centerY = canvasRef.current ? canvasRef.current.clientHeight / 2 / zoom - canvasOffset.y : 100

    addNode({
      id: `node-${Date.now()}`,
      title: "New Scene",
      content: "Write your scene content here...",
      position: { x: centerX, y: centerY },
      choices: [],
    })
  }

  const handleNodeMouseDown = (e: React.MouseEvent, nodeId: string) => {
    e.stopPropagation()

    if (isConnecting) {
      // If we're in connecting mode and already have a start node
      if (connectionStart && connectionStart !== nodeId) {
        addConnection({
          id: `conn-${Date.now()}`,
          sourceId: connectionStart,
          targetId: nodeId,
          label: "Continue",
        })
        setIsConnecting(false)
        setConnectionStart(null)
      } else {
        // Start a new connection
        setConnectionStart(nodeId)
      }
      return
    }

    setIsDragging(true)
    setDraggedNodeId(nodeId)

    const node = nodes.find((n) => n.id === nodeId)
    if (node) {
      const rect = (e.target as HTMLElement).getBoundingClientRect()
      setDragOffset({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      })
    }
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging && draggedNodeId) {
      const node = nodes.find((n) => n.id === draggedNodeId)
      if (node && canvasRef.current) {
        const rect = canvasRef.current.getBoundingClientRect()
        const x = (e.clientX - rect.left - dragOffset.x) / zoom - canvasOffset.x
        const y = (e.clientY - rect.top - dragOffset.y) / zoom - canvasOffset.y

        updateNodePosition(draggedNodeId, { x, y })
      }
    }
  }

  const handleMouseUp = () => {
    setIsDragging(false)
    setDraggedNodeId(null)
  }

  const handleZoomIn = () => {
    setZoom((prev) => Math.min(prev + 0.1, 2))
  }

  const handleZoomOut = () => {
    setZoom((prev) => Math.max(prev - 0.1, 0.5))
  }

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      canvasRef.current?.requestFullscreen()
      setIsFullscreen(true)
    } else {
      document.exitFullscreen()
      setIsFullscreen(false)
    }
  }

  const toggleConnectionMode = () => {
    setIsConnecting(!isConnecting)
    if (isConnecting) {
      setConnectionStart(null)
    }
  }

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement)
    }

    document.addEventListener("fullscreenchange", handleFullscreenChange)
    return () => {
      document.removeEventListener("fullscreenchange", handleFullscreenChange)
    }
  }, [])

  return (
    <div className="bg-amber-100 rounded-lg border border-amber-200 p-4 h-[calc(100vh-200px)] overflow-hidden">
      <div className="flex justify-between mb-4">
        <div className="flex space-x-2">
          <Button onClick={handleAddNode} size="sm" className="bg-amber-800 hover:bg-amber-900 text-amber-50">
            <PlusCircle className="mr-1 h-4 w-4" />
            Add Scene
          </Button>
          <Button
            onClick={toggleConnectionMode}
            size="sm"
            variant={isConnecting ? "default" : "outline"}
            className={
              isConnecting
                ? "bg-amber-800 hover:bg-amber-900 text-amber-50"
                : "border-amber-600 text-amber-600 hover:bg-amber-200"
            }
          >
            {isConnecting ? "Cancel Connection" : "Connect Scenes"}
          </Button>
        </div>
        <div className="flex space-x-2">
          <Button
            onClick={handleZoomOut}
            size="sm"
            variant="outline"
            className="border-amber-600 text-amber-600 hover:bg-amber-200"
          >
            <ZoomOut className="h-4 w-4" />
          </Button>
          <Button
            onClick={handleZoomIn}
            size="sm"
            variant="outline"
            className="border-amber-600 text-amber-600 hover:bg-amber-200"
          >
            <ZoomIn className="h-4 w-4" />
          </Button>
          <Button
            onClick={toggleFullscreen}
            size="sm"
            variant="outline"
            className="border-amber-600 text-amber-600 hover:bg-amber-200"
          >
            {isFullscreen ? <Minimize className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      <div
        ref={canvasRef}
        className="relative w-full h-full overflow-auto bg-amber-50 rounded border border-amber-300"
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        <div
          className="absolute min-w-full min-h-full"
          style={{
            transform: `scale(${zoom})`,
            transformOrigin: "0 0",
          }}
        >
          {/* Render connections */}
          <svg className="absolute top-0 left-0 w-full h-full pointer-events-none">
            {connections.map((connection) => {
              const sourceNode = nodes.find((n) => n.id === connection.sourceId)
              const targetNode = nodes.find((n) => n.id === connection.targetId)

              if (!sourceNode || !targetNode) return null

              const sourceX = sourceNode.position.x + 150 // Node width / 2
              const sourceY = sourceNode.position.y + 75 // Node height / 2
              const targetX = targetNode.position.x + 150
              const targetY = targetNode.position.y + 75

              // Calculate control points for a curved line
              const dx = targetX - sourceX
              const dy = targetY - sourceY
              const controlX = sourceX + dx / 2
              const controlY = sourceY + dy / 2

              return (
                <g key={connection.id}>
                  <path
                    d={`M ${sourceX} ${sourceY} Q ${controlX} ${controlY} ${targetX} ${targetY}`}
                    stroke="#92400e"
                    strokeWidth="2"
                    fill="none"
                    markerEnd="url(#arrowhead)"
                  />
                  <text>
                    <textPath
                      href={`#${connection.id}`}
                      startOffset="50%"
                      textAnchor="middle"
                      className="fill-amber-800 text-xs"
                    >
                      {connection.label}
                    </textPath>
                  </text>
                </g>
              )
            })}
            <defs>
              <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                <polygon points="0 0, 10 3.5, 0 7" fill="#92400e" />
              </marker>
            </defs>
          </svg>

          {/* Render nodes */}
          {nodes.map((node) => (
            <div
              key={node.id}
              className={`absolute w-[300px] bg-amber-200 rounded-md shadow-md border-2 ${
                connectionStart === node.id ? "border-amber-600" : "border-amber-300"
              } ${isConnecting ? "cursor-pointer" : "cursor-move"}`}
              style={{
                left: `${node.position.x}px`,
                top: `${node.position.y}px`,
              }}
              onMouseDown={(e) => handleNodeMouseDown(e, node.id)}
              onClick={() => !isDragging && !isConnecting && onNodeSelect(node.id)}
            >
              <div className="p-3 bg-amber-300 rounded-t-md flex justify-between items-center">
                <h3 className="font-medium text-amber-800 truncate">{node.title}</h3>
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-6 w-6 text-amber-800 hover:bg-amber-400 hover:text-amber-900"
                  onClick={(e) => {
                    e.stopPropagation()
                    removeNode(node.id)
                  }}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
              <div className="p-3">
                <p className="text-amber-800 text-sm line-clamp-3">{node.content}</p>
                {node.choices && node.choices.length > 0 && (
                  <div className="mt-2 space-y-1">
                    <p className="text-xs font-medium text-amber-700">Choices:</p>
                    {node.choices.map((choice, index) => (
                      <div key={index} className="text-xs text-amber-700 bg-amber-100 px-2 py-1 rounded">
                        {choice.text}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
