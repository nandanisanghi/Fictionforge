export interface Story {
  id: string
  title: string
  description: string
  coverImage?: string
  createdAt: string
  updatedAt: string
}

export interface StoryNode {
  id: string
  title: string
  content: string
  position: {
    x: number
    y: number
  }
  imageUrl?: string
  choices: Choice[]
}

export interface Choice {
  id: string
  text: string
  targetId: string | null
}

export interface Connection {
  id: string
  sourceId: string
  targetId: string
  label?: string
}
