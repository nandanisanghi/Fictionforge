"use client"

import { create } from "zustand"
import type { StoryNode, Connection, Story } from "./types"

interface StoryState {
  story: Story | null
  nodes: StoryNode[]
  connections: Connection[]

  // Actions
  loadStory: (id: string) => void
  addNode: (node: StoryNode) => void
  updateNode: (node: StoryNode) => void
  removeNode: (id: string) => void
  updateNodePosition: (id: string, position: { x: number; y: number }) => void
  addConnection: (connection: Connection) => void
  removeConnection: (id: string) => void
  updateConnection: (connection: Connection) => void
}

// Mock data for initial state
const mockStory: Story = {
  id: "story-1",
  title: "The Enchanted Forest",
  description: "A magical adventure where your choices determine the fate of an ancient forest.",
  coverImage: "/placeholder.svg?height=200&width=300",
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
}

const mockNodes: StoryNode[] = [
  {
    id: "node-1",
    title: "The Forest Entrance",
    content:
      "You stand at the entrance to an ancient forest. The trees tower above you, their branches swaying gently in the breeze. A narrow path winds its way into the darkness ahead.\n\nWhat do you do?",
    position: { x: 100, y: 100 },
    choices: [
      { id: "choice-1", text: "Follow the path deeper into the forest", targetId: "node-2" },
      { id: "choice-2", text: "Examine the strange markings on the nearest tree", targetId: "node-3" },
    ],
  },
  {
    id: "node-2",
    title: "The Clearing",
    content:
      "After walking for what seems like hours, you emerge into a sunlit clearing. In the center stands a circle of ancient stones, covered in moss and strange symbols.\n\nA soft humming sound fills the air.",
    position: { x: 500, y: 50 },
    choices: [
      { id: "choice-3", text: "Approach the stone circle", targetId: "node-4" },
      { id: "choice-4", text: "Skirt around the edge of the clearing", targetId: "node-5" },
    ],
  },
  {
    id: "node-3",
    title: "The Tree Markings",
    content:
      'As you examine the tree, you realize the markings are actually words in an ancient language. Somehow, you can understand them:\n\n"Beware the guardian of the heart. Only the pure of intention may pass."',
    position: { x: 500, y: 250 },
    choices: [
      { id: "choice-5", text: "Continue into the forest", targetId: "node-2" },
      { id: "choice-6", text: "Return to the entrance and leave", targetId: null },
    ],
  },
  {
    id: "node-4",
    title: "The Stone Circle",
    content:
      "As you step into the stone circle, the humming grows louder. The ground beneath your feet begins to glow with a soft blue light, revealing intricate patterns connecting all the stones.\n\nYou feel a presence watching you.",
    position: { x: 900, y: 100 },
    choices: [],
  },
  {
    id: "node-5",
    title: "The Forest Path",
    content:
      "You decide to avoid the stone circle and continue along a narrow path that skirts the clearing. As you walk, you notice small lights floating among the trees - are they fireflies, or something more magical?",
    position: { x: 900, y: 300 },
    choices: [],
  },
]

const mockConnections: Connection[] = [
  {
    id: "conn-1",
    sourceId: "node-1",
    targetId: "node-2",
    label: "Follow the path",
  },
  {
    id: "conn-2",
    sourceId: "node-1",
    targetId: "node-3",
    label: "Examine markings",
  },
  {
    id: "conn-3",
    sourceId: "node-3",
    targetId: "node-2",
    label: "Continue",
  },
  {
    id: "conn-4",
    sourceId: "node-2",
    targetId: "node-4",
    label: "Approach stones",
  },
  {
    id: "conn-5",
    sourceId: "node-2",
    targetId: "node-5",
    label: "Skirt around",
  },
]

export const useStoryStore = create<StoryState>((set) => ({
  story: null,
  nodes: [],
  connections: [],

  loadStory: (id: string) => {
    // In a real app, we would fetch the story from an API
    // For now, we'll use mock data
    set({
      story: mockStory,
      nodes: mockNodes,
      connections: mockConnections,
    })
  },

  addNode: (node: StoryNode) => {
    set((state) => ({
      nodes: [...state.nodes, node],
    }))
  },

  updateNode: (node: StoryNode) => {
    set((state) => ({
      nodes: state.nodes.map((n) => (n.id === node.id ? node : n)),
    }))
  },

  removeNode: (id: string) => {
    set((state) => ({
      nodes: state.nodes.filter((n) => n.id !== id),
      connections: state.connections.filter((c) => c.sourceId !== id && c.targetId !== id),
    }))
  },

  updateNodePosition: (id: string, position: { x: number; y: number }) => {
    set((state) => ({
      nodes: state.nodes.map((node) => (node.id === id ? { ...node, position } : node)),
    }))
  },

  addConnection: (connection: Connection) => {
    set((state) => ({
      connections: [...state.connections, connection],
    }))
  },

  removeConnection: (id: string) => {
    set((state) => ({
      connections: state.connections.filter((c) => c.id !== id),
    }))
  },

  updateConnection: (connection: Connection) => {
    set((state) => ({
      connections: state.connections.map((c) => (c.id === connection.id ? connection : c)),
    }))
  },
}))
