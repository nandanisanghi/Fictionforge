"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { BookOpen, ArrowLeft, Save } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"

export default function NewStoryPage() {
  const router = useRouter()
  const [storyData, setStoryData] = useState({
    title: "",
    description: "",
    coverImage: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setStoryData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real app, we would save the story to a database
    // For now, we'll just redirect to the editor
    router.push(`/stories/${Date.now()}/edit`)
  }

  return (
    <main className="min-h-screen bg-amber-50 py-8 px-4">
      <div className="max-w-3xl mx-auto">
        <Button asChild variant="ghost" className="mb-6 text-amber-800 hover:bg-amber-100">
          <Link href="/stories">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Stories
          </Link>
        </Button>

        <Card className="border-amber-200 bg-amber-100">
          <CardHeader>
            <CardTitle className="text-2xl text-amber-800 flex items-center">
              <BookOpen className="mr-2 h-6 w-6" />
              Create New Story
            </CardTitle>
            <CardDescription className="text-amber-700">
              Start your journey by giving your story a title and description
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="title" className="text-amber-800">
                  Story Title
                </Label>
                <Input
                  id="title"
                  name="title"
                  value={storyData.title}
                  onChange={handleChange}
                  placeholder="Enter a captivating title..."
                  required
                  className="border-amber-300 focus:border-amber-500 focus:ring-amber-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description" className="text-amber-800">
                  Description
                </Label>
                <Textarea
                  id="description"
                  name="description"
                  value={storyData.description}
                  onChange={handleChange}
                  placeholder="Describe your interactive story..."
                  rows={4}
                  className="border-amber-300 focus:border-amber-500 focus:ring-amber-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="coverImage" className="text-amber-800">
                  Cover Image URL (Optional)
                </Label>
                <Input
                  id="coverImage"
                  name="coverImage"
                  value={storyData.coverImage}
                  onChange={handleChange}
                  placeholder="https://example.com/image.jpg"
                  className="border-amber-300 focus:border-amber-500 focus:ring-amber-500"
                />
                {storyData.coverImage && (
                  <div className="mt-2 h-40 overflow-hidden rounded-md border border-amber-300">
                    <img
                      src={storyData.coverImage || "/placeholder.svg?height=200&width=300"}
                      alt="Cover preview"
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=200&width=300"
                      }}
                    />
                  </div>
                )}
              </div>
            </form>
          </CardContent>
          <CardFooter className="flex justify-end">
            <Button onClick={handleSubmit} className="bg-amber-800 hover:bg-amber-900 text-amber-50">
              <Save className="mr-2 h-4 w-4" />
              Create Story & Continue to Editor
            </Button>
          </CardFooter>
        </Card>
      </div>
    </main>
  )
}
