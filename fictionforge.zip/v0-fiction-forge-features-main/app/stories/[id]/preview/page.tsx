"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Home, Undo, BookOpen } from "lucide-react"
import { useStoryStore } from "@/lib/store"
import { motion, AnimatePresence } from "framer-motion"

export default function PreviewStoryPage({ params }: { params: { id: string } }) {
  const { story, nodes, connections, loadStory } = useStoryStore()
  const [currentNodeId, setCurrentNodeId] = useState<string | null>(null)
  const [currentNode, setCurrentNode] = useState<any | null>(null)
  const [history, setHistory] = useState<string[]>([])
  const [isTransitioning, setIsTransitioning] = useState(false)

  useEffect(() => {
    // In a real app, we would load the story from an API
    loadStory(params.id)
  }, [params.id, loadStory])

  useEffect(() => {
    // Find the starting node (the one with no incoming connections)
    if (nodes.length > 0 && connections.length > 0) {
      const targetNodeIds = connections.map((conn) => conn.targetId)
      const startNode = nodes.find((node) => !targetNodeIds.includes(node.id))

      if (startNode) {
        setCurrentNodeId(startNode.id)
      } else {
        // If no clear starting node, just use the first one
        setCurrentNodeId(nodes[0].id)
      }
    } else if (nodes.length > 0) {
      // If there are no connections, just use the first node
      setCurrentNodeId(nodes[0].id)
    }
  }, [nodes, connections])

  useEffect(() => {
    if (currentNodeId) {
      const node = nodes.find((n) => n.id === currentNodeId)
      if (node) {
        setCurrentNode(node)
      }
    }
  }, [currentNodeId, nodes])

  const handleChoiceClick = (targetId: string | null) => {
    if (targetId) {
      setIsTransitioning(true)
      setTimeout(() => {
        setHistory([...history, currentNodeId!])
        setCurrentNodeId(targetId)
        setIsTransitioning(false)
      }, 500)
    }
  }

  const handleGoBack = () => {
    if (history.length > 0) {
      setIsTransitioning(true)
      setTimeout(() => {
        const newHistory = [...history]
        const previousNodeId = newHistory.pop()
        setHistory(newHistory)
        setCurrentNodeId(previousNodeId!)
        setIsTransitioning(false)
      }, 500)
    }
  }

  const handleRestart = () => {
    // Find the starting node again
    const targetNodeIds = connections.map((conn) => conn.targetId)
    const startNode = nodes.find((node) => !targetNodeIds.includes(node.id))

    setIsTransitioning(true)
    setTimeout(() => {
      setHistory([])
      setCurrentNodeId(startNode ? startNode.id : nodes[0]?.id)
      setIsTransitioning(false)
    }, 500)
  }

  // Find available choices for the current node
  const availableChoices = currentNode?.choices || []

  // Also find connections where this node is the source
  const nodeConnections = connections.filter((conn) => conn.sourceId === currentNodeId)

  // Combine choices from the node and from connections
  const allChoices = [
    ...availableChoices.map((choice) => ({
      id: choice.id,
      text: choice.text,
      targetId: choice.targetId,
    })),
    ...nodeConnections.map((conn) => {
      const targetNode = nodes.find((n) => n.id === conn.targetId)
      return {
        id: conn.id,
        text: conn.label || "Continue",
        targetId: conn.targetId,
      }
    }),
  ]

  if (!story || !currentNode) {
    return (
      <div className="min-h-screen bg-amber-50 flex items-center justify-center">
        <div className="text-center">
          <BookOpen className="mx-auto h-16 w-16 text-amber-400 mb-4" />
          <h2 className="text-2xl font-semibold text-amber-800 mb-2">Loading story...</h2>
        </div>
      </div>
    )
  }

  return (
    <main className="min-h-screen bg-amber-50 flex flex-col">
      <div className="border-b border-amber-200 bg-amber-100">
        <div className="max-w-4xl mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center">
            <Button asChild variant="ghost" size="sm" className="mr-4 text-amber-800 hover:bg-amber-200">
              <Link href={`/stories/${params.id}/edit`}>
                <ArrowLeft className="mr-1 h-4 w-4" />
                Back to Editor
              </Link>
            </Button>
            <h1 className="text-xl font-semibold text-amber-800">{story.title}</h1>
          </div>
          <div className="flex space-x-2">
            <Button
              size="sm"
              variant="outline"
              className="border-amber-600 text-amber-600 hover:bg-amber-200"
              onClick={handleRestart}
            >
              <Home className="mr-1 h-4 w-4" />
              Restart
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="border-amber-600 text-amber-600 hover:bg-amber-200"
              onClick={handleGoBack}
              disabled={history.length === 0}
            >
              <Undo className="mr-1 h-4 w-4" />
              Go Back
            </Button>
          </div>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center p-4">
        <div className="max-w-2xl w-full mx-auto bg-amber-100 rounded-lg border border-amber-200 shadow-lg overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentNodeId}
              initial={{ opacity: 0, x: isTransitioning ? 100 : 0 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100 }}
              transition={{ duration: 0.5 }}
              className="flex flex-col h-full"
            >
              {currentNode.imageUrl && (
                <div className="h-64 overflow-hidden">
                  <img
                    src={currentNode.imageUrl || "/placeholder.svg"}
                    alt={currentNode.title}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      ;(e.target as HTMLImageElement).src = "/placeholder.svg?height=300&width=600"
                    }}
                  />
                </div>
              )}
              <div className="p-6">
                <h2 className="text-2xl font-semibold text-amber-800 mb-4">{currentNode.title}</h2>
                <div className="prose prose-amber mb-8 font-serif">
                  <p className="text-amber-800 whitespace-pre-line">{currentNode.content}</p>
                </div>

                {allChoices.length > 0 ? (
                  <div className="space-y-3">
                    {allChoices.map((choice) => (
                      <Button
                        key={choice.id}
                        onClick={() => handleChoiceClick(choice.targetId)}
                        className="w-full justify-start text-left bg-amber-200 hover:bg-amber-300 text-amber-800 border border-amber-300"
                        disabled={!choice.targetId}
                      >
                        {choice.text}
                      </Button>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-4 bg-amber-200 rounded-md border border-amber-300">
                    <p className="text-amber-800">The End</p>
                    <Button onClick={handleRestart} className="mt-4 bg-amber-800 hover:bg-amber-900 text-amber-50">
                      <Home className="mr-2 h-4 w-4" />
                      Start Over
                    </Button>
                  </div>
                )}
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </main>
  )
}
