"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Save, Play, Download, ArrowLeft, BookOpen, PenTool, TreesIcon as Nodes } from "lucide-react"
import StoryCanvas from "@/components/story-canvas"
import SceneEditor from "@/components/scene-editor"
import { useStoryStore } from "@/lib/store"
import { PageFlip } from "@/components/page-flip"

export default function EditStoryPage({ params }: { params: { id: string } }) {
  const [activeTab, setActiveTab] = useState("canvas")
  const [activeNodeId, setActiveNodeId] = useState<string | null>(null)

  const { story, nodes, loadStory } = useStoryStore()

  useEffect(() => {
    // In a real app, we would load the story from an API
    loadStory(params.id)
  }, [params.id, loadStory])

  const handleNodeSelect = (nodeId: string) => {
    setActiveNodeId(nodeId)
    setActiveTab("editor")
  }

  return (
    <main className="min-h-screen bg-amber-50">
      <div className="border-b border-amber-200 bg-amber-100">
        <div className="max-w-7xl mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center">
            <Button asChild variant="ghost" size="sm" className="mr-4 text-amber-800 hover:bg-amber-200">
              <Link href="/stories">
                <ArrowLeft className="mr-1 h-4 w-4" />
                Back
              </Link>
            </Button>
            <h1 className="text-xl font-semibold text-amber-800 truncate max-w-md">
              {story?.title || "Loading story..."}
            </h1>
          </div>
          <div className="flex space-x-2">
            <Button size="sm" variant="outline" className="border-amber-600 text-amber-600 hover:bg-amber-200">
              <Save className="mr-1 h-4 w-4" />
              Save
            </Button>
            <Button asChild size="sm" variant="outline" className="border-amber-600 text-amber-600 hover:bg-amber-200">
              <Link href={`/stories/${params.id}/preview`}>
                <Play className="mr-1 h-4 w-4" />
                Preview
              </Link>
            </Button>
            <Button size="sm" className="bg-amber-800 hover:bg-amber-900 text-amber-50">
              <Download className="mr-1 h-4 w-4" />
              Export
            </Button>
          </div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="max-w-7xl mx-auto px-4 py-4">
        <TabsList className="bg-amber-200 text-amber-800">
          <TabsTrigger value="canvas" className="data-[state=active]:bg-amber-800 data-[state=active]:text-amber-50">
            <Nodes className="mr-2 h-4 w-4" />
            Story Canvas
          </TabsTrigger>
          <TabsTrigger value="editor" className="data-[state=active]:bg-amber-800 data-[state=active]:text-amber-50">
            <PenTool className="mr-2 h-4 w-4" />
            Scene Editor
          </TabsTrigger>
          <TabsTrigger value="settings" className="data-[state=active]:bg-amber-800 data-[state=active]:text-amber-50">
            <BookOpen className="mr-2 h-4 w-4" />
            Story Settings
          </TabsTrigger>
        </TabsList>

        <TabsContent value="canvas" className="mt-4">
          <PageFlip>
            <StoryCanvas onNodeSelect={handleNodeSelect} />
          </PageFlip>
        </TabsContent>

        <TabsContent value="editor" className="mt-4">
          <PageFlip>
            {activeNodeId ? (
              <SceneEditor nodeId={activeNodeId} />
            ) : (
              <div className="text-center py-16 bg-amber-100 rounded-lg border border-amber-200">
                <PenTool className="mx-auto h-16 w-16 text-amber-400 mb-4" />
                <h2 className="text-2xl font-semibold text-amber-800 mb-2">No Scene Selected</h2>
                <p className="text-amber-700 mb-6">Select a node from the Story Canvas to edit its content</p>
                <Button
                  onClick={() => setActiveTab("canvas")}
                  className="bg-amber-800 hover:bg-amber-900 text-amber-50"
                >
                  <Nodes className="mr-2 h-5 w-5" />
                  Go to Story Canvas
                </Button>
              </div>
            )}
          </PageFlip>
        </TabsContent>

        <TabsContent value="settings" className="mt-4">
          <PageFlip>
            <div className="bg-amber-100 rounded-lg border border-amber-200 p-6">
              <h2 className="text-2xl font-semibold text-amber-800 mb-4">Story Settings</h2>
              <p className="text-amber-700 mb-4">Configure global settings for your interactive story</p>

              {/* Settings would go here */}
              <div className="text-amber-700">Story settings coming soon...</div>
            </div>
          </PageFlip>
        </TabsContent>
      </Tabs>
    </main>
  )
}
