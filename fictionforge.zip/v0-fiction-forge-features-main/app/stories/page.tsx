import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { PenTool, BookOpen, Play, Download, Trash2, Clock } from "lucide-react"

export default function StoriesPage() {
  // Mock data for stories
  const stories = [
    {
      id: "1",
      title: "The Enchanted Forest",
      description: "A magical adventure where your choices determine the fate of an ancient forest.",
      lastEdited: "2 days ago",
      scenes: 12,
      paths: 8,
      coverImage: "/placeholder.svg?height=200&width=300",
    },
    {
      id: "2",
      title: "Space Colony: New Beginnings",
      description: "Lead a group of colonists as they establish humanity's first settlement on a distant planet.",
      lastEdited: "5 hours ago",
      scenes: 24,
      paths: 16,
      coverImage: "/placeholder.svg?height=200&width=300",
    },
    {
      id: "3",
      title: "Murder at Midnight",
      description: "Solve a mysterious murder case where everyone is a suspect, including you.",
      lastEdited: "1 week ago",
      scenes: 18,
      paths: 12,
      coverImage: "/placeholder.svg?height=200&width=300",
    },
  ]

  return (
    <main className="min-h-screen bg-amber-50 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-amber-800">My Stories</h1>
          <Button asChild className="bg-amber-800 hover:bg-amber-900 text-amber-50">
            <Link href="/stories/new">
              <PenTool className="mr-2 h-5 w-5" />
              Create New Story
            </Link>
          </Button>
        </div>

        {stories.length === 0 ? (
          <div className="text-center py-16 bg-amber-100 rounded-lg border border-amber-200">
            <BookOpen className="mx-auto h-16 w-16 text-amber-400 mb-4" />
            <h2 className="text-2xl font-semibold text-amber-800 mb-2">No Stories Yet</h2>
            <p className="text-amber-700 mb-6">Start creating your first interactive story adventure</p>
            <Button asChild className="bg-amber-800 hover:bg-amber-900 text-amber-50">
              <Link href="/stories/new">
                <PenTool className="mr-2 h-5 w-5" />
                Create New Story
              </Link>
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {stories.map((story) => (
              <Card
                key={story.id}
                className="border-amber-200 bg-amber-100 overflow-hidden hover:shadow-md transition-shadow"
              >
                <div className="h-40 overflow-hidden">
                  <img
                    src={story.coverImage || "/placeholder.svg"}
                    alt={story.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardHeader>
                  <CardTitle className="text-amber-800">{story.title}</CardTitle>
                  <CardDescription className="text-amber-700 flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    Last edited {story.lastEdited}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-amber-700 mb-4">{story.description}</p>
                  <div className="flex space-x-4 text-sm text-amber-600">
                    <div className="flex items-center">
                      <BookOpen className="h-4 w-4 mr-1" />
                      {story.scenes} scenes
                    </div>
                    <div className="flex items-center">
                      <PenTool className="h-4 w-4 mr-1" />
                      {story.paths} paths
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <div className="flex space-x-2">
                    <Button
                      asChild
                      size="sm"
                      variant="outline"
                      className="border-amber-600 text-amber-600 hover:bg-amber-200"
                    >
                      <Link href={`/stories/${story.id}/edit`}>
                        <PenTool className="h-4 w-4 mr-1" />
                        Edit
                      </Link>
                    </Button>
                    <Button
                      asChild
                      size="sm"
                      variant="outline"
                      className="border-amber-600 text-amber-600 hover:bg-amber-200"
                    >
                      <Link href={`/stories/${story.id}/preview`}>
                        <Play className="h-4 w-4 mr-1" />
                        Preview
                      </Link>
                    </Button>
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-amber-600 hover:bg-amber-200 hover:text-amber-800"
                    >
                      <Download className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="ghost" className="text-amber-600 hover:bg-amber-200 hover:text-red-600">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </div>
    </main>
  )
}
