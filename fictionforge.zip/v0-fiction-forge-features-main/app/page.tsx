import type React from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { BookOpen, PenTool, Code, Play } from "lucide-react"
import TypewriterEffect from "@/components/typewriter-effect"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center bg-amber-50 text-amber-900">
      <div className="w-full max-w-5xl px-4 py-8">
        <div className="mb-12 text-center">
          <h1 className="mb-4 text-5xl font-bold tracking-tight">
            <span className="text-amber-800">Fiction</span>
            <span className="text-amber-600">Forge</span>
          </h1>
          <div className="h-16 mb-8">
            <TypewriterEffect
              text="Craft interactive adventures where every choice matters."
              className="text-xl text-amber-700"
            />
          </div>
          <p className="mb-8 text-lg text-amber-700">
            Build branching narratives, design immersive worlds, and share your interactive stories.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button asChild size="lg" className="bg-amber-800 hover:bg-amber-900 text-amber-50">
              <Link href="/stories/new">
                <PenTool className="mr-2 h-5 w-5" />
                Create New Story
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="border-amber-800 text-amber-800 hover:bg-amber-100">
              <Link href="/stories">
                <BookOpen className="mr-2 h-5 w-5" />
                My Stories
              </Link>
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
          <FeatureCard
            icon={<PenTool className="h-8 w-8 text-amber-600" />}
            title="Visual Story Canvas"
            description="Design your narrative with an intuitive branching node system. Visualize paths and connections."
          />
          <FeatureCard
            icon={<BookOpen className="h-8 w-8 text-amber-600" />}
            title="Rich Scene Editor"
            description="Craft each scene with formatted text and images. Create immersive story moments."
          />
          <FeatureCard
            icon={<Play className="h-8 w-8 text-amber-600" />}
            title="Interactive Preview"
            description="Test your story as readers will experience it. Ensure every path leads somewhere meaningful."
          />
          <FeatureCard
            icon={<Code className="h-8 w-8 text-amber-600" />}
            title="Export Options"
            description="Share your creation as interactive HTML or JSON. Publish anywhere or integrate with other platforms."
          />
          <FeatureCard
            icon={<BookOpen className="h-8 w-8 text-amber-600" />}
            title="Vintage Book UI"
            description="Enjoy a nostalgic reading experience with page-flip transitions and classic typography."
          />
          <FeatureCard
            icon={<PenTool className="h-8 w-8 text-amber-600" />}
            title="Coming Soon: AI Assistance"
            description="Get help generating story continuations and alternative paths with AI technology."
          />
        </div>
      </div>
    </main>
  )
}

function FeatureCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode
  title: string
  description: string
}) {
  return (
    <div className="bg-amber-100 p-6 rounded-lg border border-amber-200 shadow-sm hover:shadow-md transition-shadow">
      <div className="mb-4">{icon}</div>
      <h3 className="text-xl font-semibold mb-2 text-amber-800">{title}</h3>
      <p className="text-amber-700">{description}</p>
    </div>
  )
}
